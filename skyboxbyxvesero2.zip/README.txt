Please change "SkyboxResolution" to 2048 in "Rodina\Scripts\DataGameplay\EGOptions.lua" for this skybox!

Install:
Copy this folder in folder 'Rodina\Mods'

Mod: Skybox
Author: XVesero
--------------------
Facebook Rodina Mods Group:  https://www.facebook.com/groups/400109867348008/