Install:
Copy this folder in folder 'Rodina\Mods'

Mod: Skybox
Author: XVesero
--------------------
Facebook Rodina Mods Group:  https://www.facebook.com/groups/400109867348008/